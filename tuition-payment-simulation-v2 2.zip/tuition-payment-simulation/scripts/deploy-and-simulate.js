const { ethers } = require("hardhat");
require("dotenv").config();

function usd(n) { return Number(n) / 1e6; }

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deployer:", deployer.address);

  // 1) Deploy MockUSDC
  const Mock = await ethers.getContractFactory("MockUSDC");
  const usdc = await Mock.deploy();
  await usdc.waitForDeployment();
  console.log("MockUSDC:", await usdc.getAddress());

  // 2) Choose/resolve payee (EOA on-chain placeholder for off-chain university account)
  const payee = process.env.PAYEE_ADDRESS || deployer.address; // replace with known address if desired
  console.log("Payee (on-chain):", payee);

  // 3) Deploy TuitionPaymentVoucher with a human reference
  const Voucher = await ethers.getContractFactory("TuitionPaymentVoucher");
  const voucher = await Voucher.deploy(await usdc.getAddress(), payee, "Master's Tuition – MIU City University Miami");
  await voucher.waitForDeployment();
  console.log("Voucher:", await voucher.getAddress());

  // 4) Prepare amounts: $50 + $150 (6 decimals)
  const a = 50n * 10n ** 6n;
  const b = 150n * 10n ** 6n;

  // 5) Approve voucher to pull $200
  const approveTx = await usdc.approve(await voucher.getAddress(), a + b);
  await approveTx.wait();
  console.log("Approved $200 USDC");

  // 6) Execute split payments
  const tx = await voucher.paySplits([a, b], ["Part 1 of Tuition", "Part 2 of Tuition"]);
  const receipt = await tx.wait();
  console.log("paySplits tx hash:", receipt.hash);

  // 7) Report balances
  const balDeployer = await usdc.balanceOf(deployer.address);
  const balPayee = await usdc.balanceOf(payee);

  const report = {
    network: (await deployer.provider.getNetwork()).name,
    deployer: deployer.address,
    payee,
    token: await usdc.getAddress(),
    voucher: await voucher.getAddress(),
    splits: [
      { amount_usd: 50, memo: "Part 1 of Tuition" },
      { amount_usd: 150, memo: "Part 2 of Tuition" }
    ],
    transaction_hash: receipt.hash,
    balances_after: {
      deployer_usdc: Number(balDeployer) / 1e6,
      payee_usdc: Number(balPayee) / 1e6
    },
    timestamp: new Date().toISOString(),
    disclaimer: "SIMULATION ONLY — no real-world funds moved."
  };

  console.log("\n--- SIMULATION REPORT ---\n", report);
}

main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
