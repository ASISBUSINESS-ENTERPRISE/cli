// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transferFrom(address from, address to, uint256 value) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function decimals() external view returns (uint8);
}

contract TuitionPaymentVoucher {
    /// @notice Token used for settlement (e.g., USDC with 6 decimals)
    IERC20 public immutable token;

    /// @notice On-chain representative address for "MIU City University Miami"
    address public immutable payee;

    /// @notice Off-chain banking metadata (for audit trail only — not used on-chain for routing).
    string public constant BANK_NAME = "CITIBANK, N.A.";
    string public constant BANK_ADDRESS = "201 S. Biscayne Blvd, Miami, FL 33131";
    string public constant ACCOUNT_TITLE = "MIU CITY UNIVERSITY MIAMI";
    string public constant ACCOUNT_MAILING_ADDRESS = "111 NE 1st St, 6th Floor, Miami, FL 33132";
    string public constant ACCOUNT_NUMBER = "3290373447";
    string public constant ABA_ROUTING = "266086554";
    string public constant SWIFT_CODE = "CITIUS33";

    /// @notice Optional human-readable reference (e.g., student id / invoice number)
    string public reference;

    event PaymentIntent(address indexed payer, address indexed payee, uint256 amount, string reference);
    event PaymentExecuted(address indexed payer, address indexed payee, uint256 amount, string memo);

    constructor(IERC20 _token, address _payee, string memory _reference) {
        token = _token;
        payee = _payee;
        reference = _reference;
    }

    /// @notice Execute one or many splits as separate transfers; requires prior ERC20 approve to this contract.
    function paySplits(uint256[] calldata amounts, string[] calldata memos) external {
        require(amounts.length == memos.length, "length mismatch");
        uint256 i;
        for (i = 0; i < amounts.length; i++) {
            require(token.transferFrom(msg.sender, payee, amounts[i]), "transfer failed");
            emit PaymentExecuted(msg.sender, payee, amounts[i], memos[i]);
        }
        uint256 total = 0;
        for (i = 0; i < amounts.length; i++) total += amounts[i];
        emit PaymentIntent(msg.sender, payee, total, reference);
    }
}
