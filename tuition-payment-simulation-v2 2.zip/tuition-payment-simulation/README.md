# Tuition Payment Simulation (USDC, $50 + $150)

This bundle lets you **simulate** a $200 tuition payment (split **$50** and **$150**) to *MIU City University Miami* using a smart contract on **Hardhat** (local) or **Sepolia** (testnet). No real funds are moved.

## Banking Metadata (for reference only)
- **Account Title:** MIU CITY UNIVERSITY MIAMI
- **Bank:** CITIBANK, N.A., 201 S. Biscayne Blvd, Miami, FL 33131
- **Mailing Address:** 111 NE 1st St, 6th Floor, Miami, FL 33132
- **Account #:** 3290373447
- **ABA:** 266086554
- **SWIFT:** CITIUS33

> These are stored on-chain as **metadata** in `TuitionPaymentVoucher.sol` for audit trace, but **do not** route money. Off-chain wires must still be done by your bank.

## What it does
- Deploys a **Mock USDC (6 decimals)** token with a large test balance.
- Deploys `TuitionPaymentVoucher` pointing to a **payee EOA** (an on-chain placeholder for the university).
- Approves and transfers **$50** and **$150** in two splits.
- Prints a **SIMULATION REPORT** (JSON-ish) including the tx hash and balances.

## Quickstart
```bash
# 0) Node 18+ recommended
npm i

# 1) Local simulation (fastest)
npm run deploy:local

# 2) Sepolia testnet (optional) — requires RPC + key
cp .env.example .env
# edit .env and set: RPC_URL=..., PRIVATE_KEY=..., PAYEE_ADDRESS=0xUniversityOrYourTestEOA
npm run deploy:sepolia
```

The run will print a report like:
```json
{
  "network": "sepolia",
  "deployer": "0x...",
  "payee": "0x...",
  "token": "0x...",
  "voucher": "0x...",
  "splits": [
    {"amount_usd": 50, "memo": "Part 1 of Tuition"},
    {"amount_usd": 150, "memo": "Part 2 of Tuition"}
  ],
  "transaction_hash": "0x...",
  "balances_after": { "deployer_usdc": 9999800, "payee_usdc": 200 },
  "timestamp": "...",
  "disclaimer": "SIMULATION ONLY — no real-world funds moved."
}
```

## Real-World Transfer Checklist (off-chain)
1. Call your bank / use the banking app **wire transfer** feature.
2. Beneficiary: **MIU City University Miami**, Account **3290373447** (Citibank, N.A.).
3. **Domestic (ABA: 266086554)** or **International (SWIFT: CITIUS33)** as applicable.
4. Memo/Reference: *Master's Tuition – Your Name / Student ID*.
5. Save the bank **wire confirmation** and send it to the university bursar.

> This repo is purely for **simulation and audit artifacts**.


---
### Fast path
```bash
# local
bash run.sh

# or testnet (create .env from .env.sepolia.example, then)
bash run.sh
```
