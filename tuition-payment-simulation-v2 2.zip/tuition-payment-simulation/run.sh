#!/usr/bin/env bash
set -euo pipefail
if [ ! -f package-lock.json ]; then npm i; fi
if [ -f .env ]; then
  echo "Using existing .env and running on Sepolia..."
  npx hardhat run --network sepolia scripts/deploy-and-simulate.js
else
  echo "No .env found. Running local Hardhat network..."
  npx hardhat run scripts/deploy-and-simulate.js
fi
