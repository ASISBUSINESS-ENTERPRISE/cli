# COMPLIANCE & RISK — Mainnet
- Fixed supply ERC-20; no admin keys.
- Publish treasury addresses, balances, reports (monthly IGAPS 21:21).
- UI geofence as applicable; avoid return promises.
