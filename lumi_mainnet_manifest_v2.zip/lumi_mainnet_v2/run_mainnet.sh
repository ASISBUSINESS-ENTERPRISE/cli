#!/usr/bin/env bash
set -euo pipefail

NETWORK="mainnet"

echo "[1/6] Compile"
npx hardhat compile

echo "[2/6] Test (optional)"
npx hardhat test || true

echo "[3/6] Deploy"
DEPLOY_LOG=$(npx hardhat run scripts/deploy_lumi.js --network "$NETWORK" | tee /dev/stderr)
ADDRESS=$(echo "$DEPLOY_LOG" | sed -n 's/.*LUMI deployed at: \(0x[0-9a-fA-F]\{40\}\).*/\1/p')
if [ -z "${ADDRESS}" ]; then echo "Cannot parse deployed address"; exit 1; fi
echo "$ADDRESS" > .deployed_address_mainnet
echo "[OK] Deployed: $ADDRESS"

echo "[4/6] Verify"
npx hardhat verify --network "$NETWORK" "$ADDRESS" "$SUPERMOON_TREASURY" "$CASABECI_FUNDS" "$SUPERMOON_SHARE_BPS" || true

echo "[5/6] Readback"
cast call "$ADDRESS" "name()(string)" || true
cast call "$ADDRESS" "symbol()(string)" || true
cast call "$ADDRESS" "totalSupply()(uint256)" || true

echo "[6/6] Archive"
sha256sum MANIFEST_MAINNET.yaml SAFE_POLICY.md SNAPSHOT_PROPOSAL.md LIQUIDITY.md run_mainnet.sh > archive_mainnet_hashes.sha256
echo "DONE"
