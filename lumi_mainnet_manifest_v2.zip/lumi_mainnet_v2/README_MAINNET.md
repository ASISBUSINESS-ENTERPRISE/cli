# LUMI — Mainnet Activation (v2)
1) Copy `.env.mainnet.example` → `.env` (fill real values).
2) Ensure Hardhat v2 + Toolbox v5 present.
3) Run: `chmod +x run_mainnet.sh && ./run_mainnet.sh`
