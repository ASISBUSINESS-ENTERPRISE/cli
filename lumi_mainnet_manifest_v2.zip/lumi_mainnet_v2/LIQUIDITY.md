# LIQUIDITY — Uniswap v3
- Fee tiers: 1% to start, 0.3% after volume stabilizes.
- Provide initial LUMI/USDC liquidity (placeholders). Adjust by policy.
- Register pool on major trackers post-verify.
