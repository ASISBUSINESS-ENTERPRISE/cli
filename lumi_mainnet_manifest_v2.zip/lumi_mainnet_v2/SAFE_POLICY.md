# SAFE / Multisig Policy — LUMI Mainnet (v2)
- SUPERMOON Treasury: 2-of-3
- CASABECI Funds: 2-of-3
- 24h timelock on outbound transfers above policy threshold.
- Daily outbound cap for LUMI and quote assets.
- Signer rotation only via on-chain proposal + signed minutes.
