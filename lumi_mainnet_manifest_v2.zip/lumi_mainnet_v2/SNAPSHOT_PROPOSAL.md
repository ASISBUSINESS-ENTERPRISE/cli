# SNAPSHOT PROPOSAL — LUMI DAO Genesis
Title: Activate LUMI DAO Treasury Policy v1.0
Actions:
1) Ratify LUMI v1 mainnet deployment.
2) Approve SAFE policy (2-of-3, timelock, daily cap).
3) Bootstrap LUMI/USDC liquidity.
4) Adopt 2% buyback of net revenue.
